import React from 'react'

export default function Thumbnail() {
  return (
    <div>
      <h1>Thumbail</h1>
    </div>
  )
}
