import React from 'react'

export default function General() {
  return (
    <div>
      <h1>General</h1>
    </div>
  )
}
