import React from 'react'

export default function Redurect() {
  return (
    <div>
      <h1>Redirect</h1>
    </div>
  )
}
