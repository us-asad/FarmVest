import React from 'react'

export default function index() {
  return (
    <div>
      <h1>FORM</h1>
    </div>
  )
}
