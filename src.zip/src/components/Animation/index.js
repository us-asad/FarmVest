import React from 'react'

export default function Animation() {
  return (
    <div>
      <h1>Animation</h1>
    </div>
  )
}
