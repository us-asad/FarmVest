import React from 'react'

export default function Scheduling() {
  return (
    <div>
      <h1>Scheduling</h1>
    </div>
  )
}
